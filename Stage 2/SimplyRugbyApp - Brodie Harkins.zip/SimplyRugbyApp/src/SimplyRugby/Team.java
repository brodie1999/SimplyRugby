package SimplyRugby;

public enum Team {
	U18, 
	O18,
}
