package SimplyRugby;

public enum UserType {
	Admin, 
	Coach,
}
